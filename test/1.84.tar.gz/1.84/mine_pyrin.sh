#!/bin/bash

POOL=pyi.baikalmine.com:27271
WALLET=pyrin:qqk9nqmrtw295hmtzwya73fqqyd9msfn9yc6u2zskgylx5u9w4vfjepp2zsm5

#./lolMiner --algo PYRIN --pool $POOL --user $WALLET $@
./lolMiner --algo PYRIN --tls on --pool $POOL --coff 300 --cclk 2400 --mclk 810 --pl 400  --user $WALLET $@

